import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class DataManager {
    private final Path filePath;

    public DataManager(String fileName) {
        this.filePath = Paths.get(fileName);
    }

    public List<Student> loadStudents() {
        List<Student> students = new ArrayList<>();
        if (!Files.exists(filePath)) {
            return students;
        }

        try {
            for (String line : Files.readAllLines(filePath)) {
                if (!line.isBlank()) {
                    try {
                        students.add(Student.fromFileString(line));
                    } catch (Exception e) {
                        System.out.println("Skipped invalid record in data file.");
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Could not read student data: " + e.getMessage());
        }
        return students;
    }

    public void saveStudents(List<Student> students) {
        List<String> lines = new ArrayList<>();
        for (Student student : students) {
            lines.add(student.toFileString());
        }

        try {
            if (filePath.getParent() != null) {
                Files.createDirectories(filePath.getParent());
            }
            Files.write(filePath, lines);
        } catch (IOException e) {
            System.out.println("Could not save student data: " + e.getMessage());
        }
    }
}
