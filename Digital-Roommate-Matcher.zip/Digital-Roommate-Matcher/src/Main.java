import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final List<Student> students = new ArrayList<>();
    private static final RoommateMatcher matcher = new RoommateMatcher();
    private static final DataManager dataManager = new DataManager("data/students.txt");

    public static void main(String[] args) {
        students.addAll(dataManager.loadStudents());

        System.out.println("========================================");
        System.out.println("       DIGITAL ROOMMATE MATCHER");
        System.out.println("========================================");

        boolean running = true;
        while (running) {
            showMenu();
            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1 -> registerStudent();
                case 2 -> viewProfiles();
                case 3 -> searchStudent();
                case 4 -> updateProfile();
                case 5 -> deleteProfile();
                case 6 -> findMatches();
                case 7 -> viewMatchDetails();
                case 8 -> {
                    dataManager.saveStudents(students);
                    System.out.println("Data saved. Thank you for using Digital Roommate Matcher!");
                    running = false;
                }
                default -> System.out.println("Invalid choice. Please enter 1-8.");
            }
        }
        scanner.close();
    }

    private static void showMenu() {
        System.out.println("\n--------------- MENU ---------------");
        System.out.println("1. Register Student");
        System.out.println("2. View Student Profiles");
        System.out.println("3. Search Student");
        System.out.println("4. Update Profile");
        System.out.println("5. Delete Profile");
        System.out.println("6. Find Roommate Matches");
        System.out.println("7. View Match Details");
        System.out.println("8. Exit");
        System.out.println("------------------------------------");
    }

    private static void registerStudent() {
        int id = readInt("Enter Student ID: ");
        if (findStudent(id) != null) {
            System.out.println("A student with this ID already exists.");
            return;
        }

        String name = readNonEmpty("Enter Name: ");
        String sleep = choose("Sleep Schedule", new String[]{"Early", "Regular", "Late"});
        String study = choose("Study Schedule", new String[]{"Morning", "Afternoon", "Evening", "Night"});
        String cleanliness = choose("Cleanliness", new String[]{"Low", "Medium", "High"});
        String noise = choose("Noise Preference", new String[]{"Quiet", "Moderate", "Lively"});
        String ac = choose("AC Preference", new String[]{"Yes", "No"});
        String social = choose("Social Preference", new String[]{"Private", "Moderate", "Social"});
        String food = choose("Food Preference", new String[]{"Vegetarian", "Non-Vegetarian", "No Preference"});
        String room = choose("Room Preference", new String[]{"Single", "Double", "Triple"});
        List<String> hobbies = readHobbies();

        students.add(new Student(id, name, sleep, study, cleanliness, noise,
                ac, social, food, room, hobbies));
        dataManager.saveStudents(students);
        System.out.println("Student profile created successfully.");
    }

    private static void viewProfiles() {
        if (students.isEmpty()) {
            System.out.println("No student profiles available.");
            return;
        }
        for (Student student : students) {
            student.display();
        }
    }

    private static void searchStudent() {
        int id = readInt("Enter Student ID to search: ");
        Student student = findStudent(id);
        if (student == null) {
            System.out.println("Student not found.");
        } else {
            student.display();
        }
    }

    private static void updateProfile() {
        int id = readInt("Enter Student ID to update: ");
        Student student = findStudent(id);
        if (student == null) {
            System.out.println("Student not found.");
            return;
        }

        System.out.println("Enter the updated information:");
        String name = readNonEmpty("Name: ");
        String sleep = choose("Sleep Schedule", new String[]{"Early", "Regular", "Late"});
        String study = choose("Study Schedule", new String[]{"Morning", "Afternoon", "Evening", "Night"});
        String cleanliness = choose("Cleanliness", new String[]{"Low", "Medium", "High"});
        String noise = choose("Noise Preference", new String[]{"Quiet", "Moderate", "Lively"});
        String ac = choose("AC Preference", new String[]{"Yes", "No"});
        String social = choose("Social Preference", new String[]{"Private", "Moderate", "Social"});
        String food = choose("Food Preference", new String[]{"Vegetarian", "Non-Vegetarian", "No Preference"});
        String room = choose("Room Preference", new String[]{"Single", "Double", "Triple"});
        List<String> hobbies = readHobbies();

        student.updateProfile(name, sleep, study, cleanliness, noise, ac,
                social, food, room, hobbies);
        dataManager.saveStudents(students);
        System.out.println("Profile updated successfully.");
    }

    private static void deleteProfile() {
        int id = readInt("Enter Student ID to delete: ");
        Student student = findStudent(id);
        if (student == null) {
            System.out.println("Student not found.");
            return;
        }

        String confirm = readNonEmpty("Type YES to confirm deletion: ");
        if (confirm.equalsIgnoreCase("YES")) {
            students.remove(student);
            dataManager.saveStudents(students);
            System.out.println("Profile deleted.");
        } else {
            System.out.println("Deletion cancelled.");
        }
    }

    private static void findMatches() {
        int id = readInt("Enter Student ID: ");
        Student target = findStudent(id);
        if (target == null) {
            System.out.println("Student not found.");
            return;
        }

        List<MatchResult> results = matcher.findMatches(target, students);
        if (results.isEmpty()) {
            System.out.println("No other student profiles are available for matching.");
            return;
        }

        System.out.println("\n========== TOP ROOMMATE MATCHES ==========");
        int limit = Math.min(5, results.size());
        for (int i = 0; i < limit; i++) {
            MatchResult result = results.get(i);
            System.out.printf("%d. %s (ID: %d) - %d%% - %s%n",
                    i + 1, result.getStudent().getName(),
                    result.getStudent().getStudentId(),
                    result.getScore(), result.getCategory());
        }
    }

    private static void viewMatchDetails() {
        int firstId = readInt("Enter your Student ID: ");
        Student first = findStudent(firstId);
        if (first == null) {
            System.out.println("Student not found.");
            return;
        }

        int secondId = readInt("Enter roommate Student ID: ");
        Student second = findStudent(secondId);
        if (second == null || firstId == secondId) {
            System.out.println("Second student not found or IDs are the same.");
            return;
        }

        MatchResult result = matcher.calculateMatch(first, second);
        System.out.println("\n========== MATCH ANALYSIS ==========");
        System.out.println("Student: " + second.getName());
        System.out.println("Compatibility Score: " + result.getScore() + "%");
        System.out.println("Category: " + result.getCategory());

        System.out.println("\nCompatible Areas:");
        if (result.getCompatibleAreas().isEmpty()) {
            System.out.println("- None");
        } else {
            for (String item : result.getCompatibleAreas()) {
                System.out.println("✓ " + item);
            }
        }

        System.out.println("\nPotential Differences:");
        if (result.getDifferences().isEmpty()) {
            System.out.println("- No major differences found.");
        } else {
            for (String item : result.getDifferences()) {
                System.out.println("! " + item);
            }
        }

        System.out.println("\nNote: The score is a rule-based compatibility estimate based only on");
        System.out.println("the preferences entered into this application.");
    }

    private static Student findStudent(int id) {
        for (Student student : students) {
            if (student.getStudentId() == id) {
                return student;
            }
        }
        return null;
    }

    private static int readInt(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    private static String readNonEmpty(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (!input.isEmpty() && !input.contains("|")) {
                return input;
            }
            System.out.println("Input cannot be empty or contain '|'.");
        }
    }

    private static String choose(String label, String[] options) {
        System.out.println("\n" + label + ":");
        for (int i = 0; i < options.length; i++) {
            System.out.println((i + 1) + ". " + options[i]);
        }
        while (true) {
            int choice = readInt("Choose an option: ");
            if (choice >= 1 && choice <= options.length) {
                return options[choice - 1];
            }
            System.out.println("Invalid option.");
        }
    }

    private static List<String> readHobbies() {
        System.out.print("Enter hobbies separated by commas (or type None): ");
        String input = scanner.nextLine().trim();
        if (input.equalsIgnoreCase("None") || input.isEmpty()) {
            return new ArrayList<>();
        }
        return new ArrayList<>(Arrays.asList(input.split("\\s*,\\s*")));
    }
}
