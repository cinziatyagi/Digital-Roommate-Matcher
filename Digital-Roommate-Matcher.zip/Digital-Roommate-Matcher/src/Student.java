import java.util.ArrayList;
import java.util.List;

public class Student {
    private int studentId;
    private String name;
    private String sleepSchedule;
    private String studySchedule;
    private String cleanliness;
    private String noisePreference;
    private String acPreference;
    private String socialPreference;
    private String foodPreference;
    private String roomPreference;
    private List<String> hobbies;

    public Student(int studentId, String name, String sleepSchedule,
                   String studySchedule, String cleanliness,
                   String noisePreference, String acPreference,
                   String socialPreference, String foodPreference,
                   String roomPreference, List<String> hobbies) {
        this.studentId = studentId;
        this.name = name;
        this.sleepSchedule = sleepSchedule;
        this.studySchedule = studySchedule;
        this.cleanliness = cleanliness;
        this.noisePreference = noisePreference;
        this.acPreference = acPreference;
        this.socialPreference = socialPreference;
        this.foodPreference = foodPreference;
        this.roomPreference = roomPreference;
        this.hobbies = new ArrayList<>(hobbies);
    }

    public int getStudentId() { return studentId; }
    public String getName() { return name; }
    public String getSleepSchedule() { return sleepSchedule; }
    public String getStudySchedule() { return studySchedule; }
    public String getCleanliness() { return cleanliness; }
    public String getNoisePreference() { return noisePreference; }
    public String getAcPreference() { return acPreference; }
    public String getSocialPreference() { return socialPreference; }
    public String getFoodPreference() { return foodPreference; }
    public String getRoomPreference() { return roomPreference; }
    public List<String> getHobbies() { return new ArrayList<>(hobbies); }

    public void updateProfile(String name, String sleepSchedule,
                              String studySchedule, String cleanliness,
                              String noisePreference, String acPreference,
                              String socialPreference, String foodPreference,
                              String roomPreference, List<String> hobbies) {
        this.name = name;
        this.sleepSchedule = sleepSchedule;
        this.studySchedule = studySchedule;
        this.cleanliness = cleanliness;
        this.noisePreference = noisePreference;
        this.acPreference = acPreference;
        this.socialPreference = socialPreference;
        this.foodPreference = foodPreference;
        this.roomPreference = roomPreference;
        this.hobbies = new ArrayList<>(hobbies);
    }

    public String toFileString() {
        return studentId + "|" + name + "|" + sleepSchedule + "|" + studySchedule
                + "|" + cleanliness + "|" + noisePreference + "|" + acPreference
                + "|" + socialPreference + "|" + foodPreference + "|"
                + roomPreference + "|" + String.join(",", hobbies);
    }

    public static Student fromFileString(String line) {
        String[] p = line.split("\\|", -1);
        if (p.length != 11) {
            throw new IllegalArgumentException("Invalid student record.");
        }
        List<String> hobbyList = new ArrayList<>();
        if (!p[10].isBlank()) {
            for (String h : p[10].split(",")) {
                hobbyList.add(h.trim());
            }
        }
        return new Student(Integer.parseInt(p[0]), p[1], p[2], p[3], p[4],
                p[5], p[6], p[7], p[8], p[9], hobbyList);
    }

    public void display() {
        System.out.println("\n----- Student Profile -----");
        System.out.println("ID: " + studentId);
        System.out.println("Name: " + name);
        System.out.println("Sleep Schedule: " + sleepSchedule);
        System.out.println("Study Schedule: " + studySchedule);
        System.out.println("Cleanliness: " + cleanliness);
        System.out.println("Noise Preference: " + noisePreference);
        System.out.println("AC Preference: " + acPreference);
        System.out.println("Social Preference: " + socialPreference);
        System.out.println("Food Preference: " + foodPreference);
        System.out.println("Room Preference: " + roomPreference);
        System.out.println("Hobbies: " + String.join(", ", hobbies));
    }
}
