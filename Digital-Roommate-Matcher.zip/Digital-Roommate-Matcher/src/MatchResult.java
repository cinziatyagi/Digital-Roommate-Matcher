import java.util.ArrayList;
import java.util.List;

public class MatchResult {
    private Student student;
    private int score;
    private List<String> compatibleAreas;
    private List<String> differences;

    public MatchResult(Student student, int score,
                       List<String> compatibleAreas, List<String> differences) {
        this.student = student;
        this.score = score;
        this.compatibleAreas = new ArrayList<>(compatibleAreas);
        this.differences = new ArrayList<>(differences);
    }

    public Student getStudent() { return student; }
    public int getScore() { return score; }
    public List<String> getCompatibleAreas() { return compatibleAreas; }
    public List<String> getDifferences() { return differences; }

    public String getCategory() {
        if (score >= 90) return "Excellent Compatibility";
        if (score >= 75) return "High Compatibility";
        if (score >= 60) return "Moderate Compatibility";
        return "Low Compatibility";
    }
}
