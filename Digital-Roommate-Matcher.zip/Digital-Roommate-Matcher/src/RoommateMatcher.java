import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class RoommateMatcher {

    public MatchResult calculateMatch(Student a, Student b) {
        int score = 0;
        List<String> compatible = new ArrayList<>();
        List<String> differences = new ArrayList<>();

        score += compare(a.getSleepSchedule(), b.getSleepSchedule(), 20,
                "Sleep schedule", compatible, differences);
        score += compare(a.getStudySchedule(), b.getStudySchedule(), 15,
                "Study schedule", compatible, differences);
        score += compare(a.getCleanliness(), b.getCleanliness(), 15,
                "Cleanliness", compatible, differences);
        score += compare(a.getNoisePreference(), b.getNoisePreference(), 15,
                "Noise preference", compatible, differences);
        score += compare(a.getAcPreference(), b.getAcPreference(), 10,
                "AC preference", compatible, differences);
        score += compare(a.getSocialPreference(), b.getSocialPreference(), 10,
                "Social preference", compatible, differences);
        score += compare(a.getFoodPreference(), b.getFoodPreference(), 5,
                "Food preference", compatible, differences);
        score += compare(a.getRoomPreference(), b.getRoomPreference(), 5,
                "Room preference", compatible, differences);

        int hobbyPoints = hobbyScore(a.getHobbies(), b.getHobbies());
        score += hobbyPoints;
        if (hobbyPoints == 5) {
            compatible.add("Several shared hobbies");
        } else if (hobbyPoints > 0) {
            compatible.add("Some shared hobbies");
        } else {
            differences.add("No common hobbies listed");
        }

        return new MatchResult(b, score, compatible, differences);
    }

    private int compare(String first, String second, int weight, String label,
                        List<String> compatible, List<String> differences) {
        if (first.equalsIgnoreCase(second)) {
            compatible.add("Similar " + label.toLowerCase());
            return weight;
        }
        differences.add("Different " + label.toLowerCase());
        return 0;
    }

    private int hobbyScore(List<String> first, List<String> second) {
        int common = 0;
        for (String a : first) {
            for (String b : second) {
                if (a.equalsIgnoreCase(b)) {
                    common++;
                    break;
                }
            }
        }
        if (common >= 2) return 5;
        if (common == 1) return 3;
        return 0;
    }

    public List<MatchResult> findMatches(Student target, List<Student> students) {
        List<MatchResult> results = new ArrayList<>();
        for (Student student : students) {
            if (student.getStudentId() != target.getStudentId()) {
                results.add(calculateMatch(target, student));
            }
        }
        results.sort(Comparator.comparingInt(MatchResult::getScore).reversed());
        return results;
    }
}
