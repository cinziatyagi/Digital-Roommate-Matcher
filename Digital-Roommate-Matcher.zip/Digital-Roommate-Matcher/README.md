# Digital Roommate Matcher

A Java-based command-line application that helps students find potential roommate matches by comparing lifestyle and accommodation preferences.

## Features

- Student registration
- Profile viewing
- Student search
- Profile update and deletion
- Rule-based roommate compatibility scoring
- Ranked top matches
- Detailed match explanation
- Potential difference/conflict identification
- File-based data persistence
- Input validation and exception handling

## Technology

- Java 17 or later
- Standard Java libraries only
- Command-line interface
- No external dependencies

## Project Structure

```text
Digital-Roommate-Matcher/
├── src/
│   ├── Main.java
│   ├── Student.java
│   ├── RoommateMatcher.java
│   ├── MatchResult.java
│   └── DataManager.java
├── data/
│   └── students.txt
├── README.md
└── .gitignore
```

## Compatibility Algorithm

The application uses a weighted rule-based scoring system:

| Preference | Weight |
|---|---:|
| Sleep schedule | 20 |
| Study schedule | 15 |
| Cleanliness | 15 |
| Noise preference | 15 |
| AC preference | 10 |
| Social preference | 10 |
| Food preference | 5 |
| Room preference | 5 |
| Hobbies | 5 |
| **Total** | **100** |

A matching preference receives its assigned weight. Hobbies can receive partial credit when one common hobby is found. The final score is shown as a percentage.

The score is a compatibility estimate based only on the preferences entered into the application; it is not a guarantee of roommate suitability.

## Requirements

Install Java 17 or newer and verify it with:

```bash
java -version
javac -version
```

## How to Run

Open a terminal in the repository root.

### 1. Compile

Linux/macOS:

```bash
mkdir -p out
javac -d out src/*.java
```

Windows PowerShell:

```powershell
New-Item -ItemType Directory -Force out
javac -d out src\*.java
```

### 2. Run

Linux/macOS:

```bash
java -cp out Main
```

Windows PowerShell:

```powershell
java -cp out Main
```

## Data Storage

Student profiles are stored in:

```text
data/students.txt
```

The file is automatically loaded when the application starts and updated when profiles are created, changed, or deleted.

## Example Workflow

1. Select **Register Student**.
2. Enter the student's preferences.
3. Register at least one more student.
4. Select **Find Roommate Matches**.
5. Enter the first student's ID.
6. Select **View Match Details** to see the score, compatible areas, and differences.

## Java Concepts Demonstrated

- Classes and objects
- Constructors
- Encapsulation
- `this` keyword
- Methods
- Conditional statements
- `switch`
- Loops
- `ArrayList`
- String handling
- Searching and sorting
- Exception handling
- File input/output

## Limitations

The current version uses a rule-based matching approach. It does not use machine learning or external databases. The result depends on the accuracy and completeness of the preferences entered by users.

## Author

Programming in Java Course Project
